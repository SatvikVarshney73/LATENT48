import os
import pandas as pd
import streamlit as st

# ---------- config ----------
DATA_PATH = "data/similarity_matrix.csv"
CONF_THRESHOLD = 0.75   # keep this in sync with the notebook's CONF_THRESHOLD
TOP_N_DEFAULT = 5

st.set_page_config(page_title="Cycle Search", page_icon="🚲", layout="centered")


@st.cache_data
def load_data(path):
    df = pd.read_csv(path)
    meta_cols = ["sighting_id", "day", "location", "time", "image_path"]
    cycle_cols = [c for c in df.columns if c not in meta_cols]
    return df, cycle_cols


st.title("🚲 Cycle Search")
st.write(
    "Apni registered cycle ID daalo — hum campus ki sightings ke saath visual "
    "similarity check karke top locations dikhayenge jaha aapki cycle dikhi ho sakti hai."
)

if not os.path.exists(DATA_PATH):
    st.error(
        f"`{DATA_PATH}` nahi mili. Notebook se export ki hui similarity_matrix.csv "
        f"aur sightings photos ko `data/` folder mein daal ke app restart karo."
    )
    st.stop()

df, cycle_ids = load_data(DATA_PATH)

col_a, col_b = st.columns([2, 1])
with col_a:
    search_id = st.text_input("Cycle ID", placeholder="e.g. CYC-005").strip().upper()
with col_b:
    top_n = st.number_input("Kitni locations", min_value=1, max_value=20, value=TOP_N_DEFAULT)

if search_id:
    if search_id not in cycle_ids:
        st.error(f"'{search_id}' registered cycles mein nahi mili.")
        st.caption("Registered IDs: " + ", ".join(cycle_ids))
    else:
        ranked = df[["sighting_id", "day", "location", "time", "image_path", search_id]].copy()
        ranked = ranked.rename(columns={search_id: "match_score"})
        ranked = ranked.sort_values("match_score", ascending=False).head(int(top_n))

        best = ranked.iloc[0]
        if best["match_score"] >= CONF_THRESHOLD:
            st.success(
                f"Sabse zyada chance hai ki aapki cycle **{best['location']}** mein hai "
                f"({best['day']} {best['time']} ko dekhi gayi)."
            )
        else:
            st.warning(
                "Koi bhi sighting confidently match nahi hui — neeche diye gaye possible "
                "locations manually check kar lo."
            )

        st.subheader(f"{search_id} ke liye top {len(ranked)} suggested locations")

        for _, row in ranked.iterrows():
            confident = row["match_score"] >= CONF_THRESHOLD
            tag = "✅ Confident match" if confident else "🔎 Possible match"

            img_col, info_col = st.columns([1, 2])
            with img_col:
                if isinstance(row["image_path"], str) and os.path.exists(row["image_path"]):
                    st.image(row["image_path"], width=180)
                else:
                    st.caption("(photo not found)")
            with info_col:
                st.markdown(f"**{tag}**")
                st.write(f"📍 Location: **{row['location']}**")
                st.write(f"🕒 Seen: {row['day']} at {row['time']}")
                st.write(f"Similarity score: `{row['match_score']:.4f}`")
            st.divider()

st.caption(
    "Matching CLIP (ViT-B/32) embeddings se hoti hai — scores absolute proof nahi, "
    "balki visual similarity ka estimate hai. Confident tag threshold se upar wale "
    "matches ko diya jata hai."
)
